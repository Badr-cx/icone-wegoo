#!/system/bin/sh
ACTION=$1

PLUGIN_PATH="/mnt/plugin/wolfPIP"

PIP_WIDTH=320
PIP_HEIGHT=180
POS_X=960
POS_Y=540

start_pip() {
    echo "Starting PIP on Hisilicon..."
    hisi_player_service --pip 1 --x $POS_X --y $POS_Y --w $PIP_WIDTH --h $PIP_HEIGHT --same-tp 1 &
}

stop_pip() {
    echo "Stopping PIP..."
    killall hisi_player_service
}

case "$ACTION" in
    start)
        start_pip
        ;;
    stop)
        stop_pip
        ;;
    *)
        echo "Usage: $0 {start|stop}"
        exit 1
        ;;
esac