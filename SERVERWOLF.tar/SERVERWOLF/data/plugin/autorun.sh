#!/system/bin/sh

setprop net.dns1 1.1.1.1
setprop net.dns2 8.8.8.8

sleep 10

[ -d "/data/plugin/ncamx" ] && DIR="/data/plugin/ncamx" || DIR="/data/plugin/ncam"
CONF="$DIR/ncam.conf"

URL="https://gitlab.com/ncam1/houssamfifi9-project/-/raw/main/ncam.server"

curl -k -L -s "$URL" > $DIR/ncam.server

sed -i 's/\r//' $DIR/ncam.server
chmod 644 $DIR/ncam.server

[ -f $CONF ] || touch $CONF
sed -i 's/^clienttimeout.*/clienttimeout = 8000/' $CONF
sed -i 's/^fallbacktimeout.*/fallbacktimeout = 4000/' $CONF
sed -i 's/^logfile.*/logfile = \/tmp\/ncam.log/' $CONF

rm -rf /tmp/.ncam*
rm -f /tmp/ncam.log
echo 3 > /proc/sys/vm/drop_caches

killall -9 ncam Orca NCamx_FreeServer 2>/dev/null
sleep 2

chmod 755 $DIR/ncam 2>/dev/null
$DIR/ncam -b -C $CONF &

sleep 2
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &

while true; do
    sleep 43200
    rm -f /tmp/ncam.log
    echo 3 > /proc/sys/vm/drop_caches
done &

echo "✅ System Online"