#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s [start|stop]\n", argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "start") == 0) {
        printf("Starting PIP (Same TP) on Hisilicon...\n");
        // أمر النظام للخدمة الداخلية لعرض PIP على نفس التردد
        system("hisi_player_service --pip 1 --x 960 --y 540 --w 320 --h 180 --same-tp 1 &");
    } else if (strcmp(argv[1], "stop") == 0) {
        printf("Stopping PIP...\n");
        system("killall hisi_player_service");
    }

    return 0;
}