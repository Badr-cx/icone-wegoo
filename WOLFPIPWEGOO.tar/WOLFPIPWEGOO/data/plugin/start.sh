#!/bin/sh
ACTION=$1

# تحديد مسار البلجيك ديناميكياً أينما تم وضعه في الجهاز
PLUGIN_PATH="$(cd "$(dirname "$0")" && pwd)"

# التأكد من إعطاء صلاحية التنفيذ للملف الباينري في حال تم نقده
chmod +x "$PLUGIN_PATH/wolf_pip_bin"

case "$ACTION" in
    start)
        "$PLUGIN_PATH/wolf_pip_bin" start
        ;;
    stop)
        "$PLUGIN_PATH/wolf_pip_bin" stop
        ;;
    *)
        echo "Usage: $0 {start|stop}"
        exit 1
        ;;
esac