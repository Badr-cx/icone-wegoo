#################################################################################
#                               ncam.fs == CCcam.cfg                             #
#                                                                               #
# C: <hostname> <port> <username> <password> <wantemus>                         #
# N: <ip> <port> <username> <pass> <des(14byte)> <nr_of_hops_away (default: 1)> #
# R: <ip> <port> <ca4> <id6> <nr_of_hops_away (default: 1)>                     #
# L: <ip> <port> <username> <pass> <ca4> <id6> <nr_of_hops_away (default: 1)>   #
#                                                                               #
# http://<url>/... # (C, N: load rows from the URL using libcurl ...)           #
#                                                                               #
# Line Enable/Disable =? (" # ")                                                #
#################################################################################
#
# --- Your Gist ---
https://gist.githubusercontent.com/Badr-cx/eb1232c638a8adf7382067a131970de8/raw/gistfile1.txt

# --- Additional Free Servers Sites ---
https://cccam-premium.pro/free-cccam/
https://cccamia.com/cccamfree1/get.php
http://free.cccambird.com/freecccam.php
https://bosscccam.co/Test.php
https://cccamspot.com/cccamfree/get.php
http://cccamgoo.com/free5/get2.php
http://cccammania.com/free5/get2.php
https://cccamz.co/FREEN12/new0.php
https://realcccam.com/freecccam/index.php
https://thecccam.com/cccam-free.php
https://cccamas.com/free/get.php
https://www.cccamprime.com/cccam48h.php
http://www.premiumcccam.store/TEST24.php

# etc...
####### preset servers #########
##     SERVER0 to SERVER20     ##
################################