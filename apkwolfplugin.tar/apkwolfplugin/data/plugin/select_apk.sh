#!/bin/sh

# تفعيل تثبيت التطبيقات من مصادر خارجية
settings put global install_non_market_apps 1

# تحديد مسارات USB
USB_PATH="/storage"

# إنشاء قائمة مؤقتة بالملفات
TEMP_LIST="/tmp/apk_list.txt"
rm -f "$TEMP_LIST"

echo "=== البحث عن ملفات APK في USB ==="
find "$USB_PATH" /mnt/media_rw -name "*.apk" 2>/dev/null > "$TEMP_LIST"

if [ ! -s "$TEMP_LIST" ]; then
    echo "لم يتم العثور على أي ملف APK في USB!"
    sleep 3
    exit 1
fi

echo ""
echo "اختر رقم التطبيق الذي تريد تثبيته:"
echo "---------------------------------"

i=1
while IFS= read -r line; do
    filename=$(basename "$line")
    echo "[$i] $filename"
    eval "apk_$i=\"$line\""
    i=$((i + 1))
done < "$TEMP_LIST"

echo "---------------------------------"
read -p "أدخل رقم الاختيار: " CHOICE

eval SELECTED_APK=\$apk_$CHOICE

if [ -n "$SELECTED_APK" ] && [ -f "$SELECTED_APK" ]; then
    echo "جاري تثبيت: $(basename "$SELECTED_APK")..."
    pm install -r "$SELECTED_APK"
    if [ $? -eq 0 ]; then
        echo "تم التثبيت بنجاح!"
    else
        echo "فشل التثبيت."
    fi
else
    echo "إختيار غير صحيح!"
fi

sleep 3
exit 0