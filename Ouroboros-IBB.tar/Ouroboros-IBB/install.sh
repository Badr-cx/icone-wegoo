#!/bin/sh
# سكريبت تثبيت بلوعين IBB لجهاز الآيكون Wegoo

PLUGIN_DIR="/mnt/shell/emulated/0/plugin/tuxbox/config"
BIN_DIR="/data/plugin/ibb"

echo "[Installing] Creating Directories..."
mkdir -p $PLUGIN_DIR
mkdir -p $BIN_DIR

echo "[Installing] Copying files..."
cp ibbservice.py $BIN_DIR/
cp ncam.conf $PLUGIN_DIR/

echo "[Permissions] Setting Root permissions..."
chown -R 0:0 $BIN_DIR
chown -R 0:0 $PLUGIN_DIR

echo "[Permissions] Setting Chmod 755..."
chmod 755 $BIN_DIR/ibbservice.py
chmod 755 $PLUGIN_DIR/ncam.conf

python $BIN_DIR/ibbservice.py &
echo "[Success] IBB Plugin installed and started!"
