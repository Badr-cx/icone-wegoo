#!/bin/sh
# سكريبت تشغيل خاصية IBB تلقائياً لجهاز الآيكون

DIR="/data/plugin/ibb"

# إعطاء صلاحيات التشغيل لملف البايثون
chmod 755 $DIR/ibbservice.py

# تشغيل سكربت البايثون في الخلفية لربط الـ DVBAPI مع خدمة الـ IBB
python $DIR/ibbservice.py &

echo "[Success] IBB Service Core Started!"