#!/usr/bin/env python
# -*- coding: utf-8 -*-
import socket
import time
import os

DVBAPI_PORT = 9000
HOST = '127.0.0.1'

def connect_dvbapi():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((HOST, DVBAPI_PORT))
            print("[IBB Service] Connected to DVBAPI successfully.")
            return s
        except socket.error:
            print("[IBB Service] Waiting for CAM connection...")
            time.sleep(5)

def handle_ibb_data():
    sock = connect_dvbapi()
    while True:
        try:
            data = sock.recv(1024)
            if not data:
                sock = connect_dvbapi()
                continue
            if b'\x00\x00' in data:
                os.system("am startservice -n com.icone.stb.ibb/.IBBService")
        except Exception as e:
            print(f"[IBB Service] Error: {str(e)}")
            sock = connect_dvbapi()

if __name__ == "__main__":
    print("[IBB Service] Starting IBB Linker for Icone...")
    handle_ibb_data()
