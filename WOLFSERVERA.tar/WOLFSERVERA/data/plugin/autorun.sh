#!/system/bin/sh

busybox telnetd -p 23 -l /system/bin/sh &

setprop net.dns1 8.8.8.8
setprop net.dns2 1.1.1.1
setprop net.eth0.dns1 8.8.8.8
setprop net.eth0.dns2 1.1.1.1
setprop net.wlan0.dns1 8.8.8.8
setprop net.wlan0.dns2 1.1.1.1
setprop net.dns.primary 8.8.8.8
setprop net.dns.secondary 1.1.1.1
setprop net.dns3 9.9.9.9
setprop net.dns4 149.112.112.112

sleep 15

DIR="/data/plugin/ncamx"
CONF="$DIR/ncam.conf"
SERVER="$DIR/ncam.server"

[ -d "$DIR" ] || mkdir -p "$DIR"

curl -k -L -s "https://www.dropbox.com/scl/fi/ptf8ug25dg64azx7d7ock/CCcam.cfg?rlkey=zk77a41lv8argc18876usnme2&st=yrn84vm2&dl=1" > $DIR/CCcam.cfg
curl -k -L -s "https://www.dropbox.com/scl/fi/8op4q61c0mt327fp0uobc/ncam.server?rlkey=6uk7i5mq661oysx37dzp61ta0&st=2227nkae&dl=1" > $SERVER
curl -k -L -s "https://www.dropbox.com/scl/fi/p0cc4khokd8yqou6xnzdw/SoftCam.Key?rlkey=4btxvxxt4whxi43mr2poiet38&st=x7dxmufy&dl=1" > $DIR/SoftCam.Key

[ -f $CONF ] || touch $CONF
sed -i 's/^clienttimeout.*/clienttimeout = 12000/' $CONF
sed -i 's/^fallbacktimeout.*/fallbacktimeout = 5000/' $CONF
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $CONF
sed -i 's/^extended_cw_api.*/extended_cw_api = 1/' $CONF
grep -q "ecmfmt" $CONF || echo "ecmfmt = c&p/i/s/l:w" >> $CONF
grep -q "show_ecm_dw_source" $CONF || echo "show_ecm_dw_source = 1" >> $CONF

sed -i 's/^group.*/group = 0/' $SERVER
sed -i 's/^root.*/root = 0/' $SERVER
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $SERVER

rm -rf /tmp/.ncam*
chmod 644 $SERVER $DIR/CCcam.cfg $CONF $DIR/SoftCam.Key

killall -9 Orca NCamx_FreeServer ncam 2>/dev/null
sleep 2

chmod 755 /data/plugin/Orca /data/plugin/NCamx_FreeServer 2>/dev/null
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &