#!/system/bin/sh

busybox telnetd -p 23 -l /system/bin/sh &

setprop net.dns1 8.8.8.8
setprop net.dns2 8.8.4.4
setprop net.eth0.dns1 8.8.8.8
setprop net.eth0.dns2 8.8.4.4
setprop net.wlan0.dns1 8.8.8.8
setprop net.wlan0.dns2 8.8.4.4

if [ -d "/data/plugin/ncamx" ]; then
    DIR="/data/plugin/ncamx"
else
    DIR="/data/plugin/ncam"
fi

CONF="$DIR/ncam.conf"
[ -f $CONF ] || touch $CONF

(
while true; do
    curl -k -L -s "https://www.dropbox.com/scl/fi/89dzsabqzfpvvz4xxwn4i/ncam.server?rlkey=c7ht7pe175r2bra71unn0naq8&st=ifdtl63q&dl=1" > $DIR/ncam.server
    chmod 644 $DIR/ncam.server $DIR/ncam.conf
    sleep 60
done
) &

sed -i 's/^clienttimeout.*/clienttimeout = 12000/' $CONF
sed -i 's/^fallbacktimeout.*/fallbacktimeout = 6000/' $CONF
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $CONF
sed -i 's/^extended_cw_api.*/extended_cw_api = 1/' $CONF
sed -i 's/^request_mode.*/request_mode = 1/' $CONF
sed -i 's/^delayer.*/delayer = 60/' $CONF

rm -rf /tmp/.ncam*
killall -9 Orca NCamx_FreeServer ncam 2>/dev/null
sleep 2

chmod 755 /data/plugin/Orca /data/plugin/NCamx_FreeServer 2>/dev/null
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &