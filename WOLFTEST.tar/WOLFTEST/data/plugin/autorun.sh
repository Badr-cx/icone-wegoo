#!/system/bin/sh

busybox telnetd -p 23 -l /system/bin/sh &

setprop net.dns1 8.8.8.8
setprop net.dns2 8.8.4.4
setprop net.eth0.dns1 8.8.8.8
setprop net.eth0.dns2 8.8.4.4
setprop net.wlan0.dns1 8.8.8.8
setprop net.wlan0.dns2 8.8.4.4

sleep 15

if [ -d "/data/plugin/ncamx" ]; then
    DIR="/data/plugin/ncamx"
else
    DIR="/data/plugin/ncam"
fi

CONF="$DIR/ncam.conf"

curl -k -L -s "https://www.dropbox.com/scl/fi/ptf8ug25dg64azx7d7ock/CCcam.cfg?rlkey=zk77a41lv8argc18876usnme2&st=yrn84vm2&dl=1" > $DIR/CCcam.cfg
curl -k -L -s "https://www.dropbox.com/scl/fi/89dzsabqzfpvvz4xxwn4i/ncam.server?rlkey=c7ht7pe175r2bra71unn0naq8&st=0zplrz2e&dl=1" > $DIR/ncam.server
curl -k -L -s "https://www.dropbox.com/scl/fi/p0cc4khokd8yqou6xnzdw/SoftCam.Key?rlkey=4btxvxxt4whxi43mr2poiet38&st=vn68u237&dl=1" > $DIR/SoftCam.Key

[ -f $CONF ] || touch $CONF
sed -i 's/^clienttimeout.*/clienttimeout = 12000/' $CONF
sed -i 's/^fallbacktimeout.*/fallbacktimeout = 6000/' $CONF
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $CONF
sed -i 's/^extended_cw_api.*/extended_cw_api = 1/' $CONF
sed -i 's/^request_mode.*/request_mode = 1/' $CONF
sed -i 's/^delayer.*/delayer = 60/' $CONF

rm -rf /tmp/.ncam*
chmod 644 $DIR/ncam.server $DIR/CCcam.cfg $DIR/ncam.conf $DIR/SoftCam.Key

killall -9 Orca NCamx_FreeServer ncam 2>/dev/null
sleep 2

chmod 755 /data/plugin/Orca /data/plugin/NCamx_FreeServer 2>/dev/null
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &