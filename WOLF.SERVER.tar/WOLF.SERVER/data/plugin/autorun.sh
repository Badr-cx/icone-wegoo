#!/system/bin/sh

# Telnet
busybox telnetd -p 23 -l /system/bin/sh &

# Wait for internet
sleep 5

# Get servers from Dropbox
curl -k -L -s "https://www.dropbox.com/scl/fi/ptf8ug25dg64azx7d7ock/CCcam.cfg?rlkey=zk77a41lv8argc18876usnme2&st=yrn84vm2&dl=1" > /data/plugin/ncamx/CCcam.cfg

# Start Emus
chmod 755 /data/plugin/Orca
chmod 755 /data/plugin/NCamx_FreeServer
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &
