#!/system/bin/sh

# Telnet
busybox telnetd -p 23 -l /system/bin/sh &

# Wait for internet
sleep 5

# Download CCcam.cfg
curl -k -L -s "https://www.dropbox.com/scl/fi/ptf8ug25dg64azx7d7ock/CCcam.cfg?rlkey=zk77a41lv8argc18876usnme2&st=yrn84vm2&dl=1" > /data/plugin/ncamx/CCcam.cfg

# Download ncam.server (Clean version)
curl -k -L -s "https://www.dropbox.com/scl/fi/8op4q61c0mt327fp0uobc/ncam.server?rlkey=6uk7i5mq661oysx37dzp61ta0&st=2227nkae&dl=1" > /data/plugin/ncamx/ncam.server

# Permissions
chmod 644 /data/plugin/ncamx/ncam.server
chmod 644 /data/plugin/ncamx/CCcam.cfg

# Start Emus
chmod 755 /data/plugin/Orca
chmod 755 /data/plugin/NCamx_FreeServer
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &