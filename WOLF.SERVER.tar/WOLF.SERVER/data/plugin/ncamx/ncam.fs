
################# CCcam Lines ############
# C: yourhost.dyndns.org 12000 user pass
C: 8k-cam.myftp.org 12000 razik 45782497
C: 164.68.126.58 10000 07112024 tatoufdz

C: 62.171.169.70 44000 sport01 sport01

C: 62.171.169.70 44000 sport02 sport02

C: 91.121.57.110 14875 46787886 38357298

C: 164.132.43.94 33300 33335 55335
C: 31.40.218.2 13000 3093 3093

C: 176.118.198.174 17000 CCcamN4L cccam-nl.com

C: 31.40.218.2 12000 mhisw9nb xmka1hfa

C: 31.40.218.2 13000 3093 3093

C: 66.42.59.97 64321 ams200 a1e0tbc


################# Newcamd Lines ############
# N: yourhost.dyndns.org 1234 user pass 01 02 03 04 05 06 07 08 09 10 11 12 13 14

############################################

############Free Server##################
# To Enable Free Server Delete #
https://cccam.premium.pro/free-cccam/
https://cccam.net/free
https://cccamia.com/free-cccam/
https://www.cccambird.com/freecccam.php
https://www.cccambird2.com/freecccam.php
https://cccamprime.com/cccam48h.php
https://skyhd.xyz/freetest/osm.php
https://www.tvlivepro.com/free_cccam_48h/
https://cccam.premium.pro/free-cccam/
https://cccam.net/free
https://cccamia.com/free-cccam/
https://www.cccambird.com/freecccam.php
https://www.cccambird2.com/freecccam.php
https://cccamprime.com/cccam48h.php
https://skyhd.xyz/freetest/osm.php
https://www.tvlivepro.com/free_cccam_48h/
https://boss-cccam.com/free-cccam-generator/
https://vipcccam.net/free-cccam/
https://4k-cline.com/free-generator/
https://fastcccam.me/free-test/
https://cccamfree.cc/daily-free/
https://vcccam.com/free-cccam-48h/
https://smart-cccam.com/free-test-cline/
https://cccam-world.com/free-server/
