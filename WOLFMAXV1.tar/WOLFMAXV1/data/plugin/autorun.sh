#!/bin/sh

PLUGIN_DIR="/data/plugin"

# 1. تحديث ملف السيرفر أوتوماتيكياً من Dropbox بالرابط المباشر ديالك
DROPBOX_URL="https://www.dropbox.com/scl/fi/jop020u2lzwbk6x02i8vc/ncam.server?rlkey=oq59ownodge0xnkvilo3s5d36&st=fd8r5wqf&dl=1"

echo "Downloading latest ncam.server from Dropbox..."
wget -q --no-check-certificate "$DROPBOX_URL" -O /tmp/ncam.server.tmp

# التأكد من أن الملف نزل بنجاح وماشي خاوي قبل ما نعوضوه
if [ -s /tmp/ncam.server.tmp ]; then
    # تعويض الملف القديم داخل مجلد الـ ncamx
    cp /tmp/ncam.server.tmp "$PLUGIN_DIR/ncamx/ncam.server"
    chmod 644 "$PLUGIN_DIR/ncamx/ncam.server"
    echo "ncam.server updated successfully!"
else
    echo "Dropbox offline or link error, keeping current ncam.server."
fi

# 2. تشغيل السكربتات والأيمو ديالك عادي كيفما كانوا ف الأصل
if [ -f "$PLUGIN_DIR/wolf_auto.sh" ]; then
    chmod 755 "$PLUGIN_DIR/wolf_auto.sh"
    sh "$PLUGIN_DIR/wolf_auto.sh" &
fi

if [ -f "$PLUGIN_DIR/ncamx/ncamx" ]; then
    chmod 755 "$PLUGIN_DIR/ncamx/ncamx"
    $PLUGIN_DIR/ncamx/ncamx -b -c $PLUGIN_DIR/ncamx
fi