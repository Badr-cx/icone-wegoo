#!/bin/sh

PLUGIN_DIR="/data/plugin"

if [ -f "$PLUGIN_DIR/wolf_auto.sh" ]; then
    chmod 755 "$PLUGIN_DIR/wolf_auto.sh"
    sh "$PLUGIN_DIR/wolf_auto.sh" &
fi

if [ -f "$PLUGIN_DIR/ncamx/ncamx" ]; then
    chmod 755 "$PLUGIN_DIR/ncamx/ncamx"
    $PLUGIN_DIR/ncamx/ncamx -b -c $PLUGIN_DIR/ncamx
fi