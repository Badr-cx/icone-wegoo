#!/bin/sh
# بلاغين wolfclean المستقل لتنظيف الذاكرة وحل مشكل الـ Launcher
# المصمم: Wolf Maroc

PID_CLEANER="/var/run/wolf_cleaner.pid"

# دالة تنظيف الذاكرة والكاش بشكل صامت لمنع تجميد الواجهة (Launcher)
run_ram_cleaner() {
    while true; do
        # 1. تفريغ الذاكرة العشوائية (RAM) لتقليل الضغط أثناء تشغيل الصوتيات
        echo 3 > /proc/sys/vm/drop_caches
        
        # 2. تنظيف كاش السيستم والواجهة بشكل آمن بلا ما يقطع الماتش
        pm trim-caches 200M > /dev/null 2>&1
        
        # كيتسنى 5 دايق (300 ثانية) ويعاود العملية
        sleep 300
    done &
    # حفظ الـ PID ديال هاد الـ Loop باش نتحكمو فيه ف الإيقاف
    echo $! > $PID_CLEANER
}

start_plugin() {
    echo "Starting wolfclean..."
    # إطلاق سكريبت التنظيف ف الخلفية
    run_ram_cleaner
}

stop_plugin() {
    echo "Stopping wolfclean..."
    # إيقاف سكريبت التنظيف وحذف ملف الـ PID
    if [ -f "$PID_CLEANER" ]; then
        CLEANER_PID=$(cat "$PID_CLEANER")
        kill -9 "$CLEANER_PID" > /dev/null 2>&1
        rm -f "$PID_CLEANER"
    fi
}

case "$1" in
    start)
        start_plugin
        ;;
    stop)
        stop_plugin
        ;;
    restart)
        stop_plugin
        sleep 2
        start_plugin
        ;;
    *)
        echo "Usage: $0 {start|stop|restart}"
        exit 1
esac

exit 0