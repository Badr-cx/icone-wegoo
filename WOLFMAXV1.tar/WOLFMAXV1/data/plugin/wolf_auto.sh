#!/bin/sh

NCAM_DIR="/data/plugin/ncamx"
CONFIG_FILE="$NCAM_DIR/ncam.server"
DROP_URL="https://www.dropbox.com/scl/fi/jop020u2lzwbk6x02i8vc/ncam.server?rlkey=oq59ownodge0xnkvilo3s5d36&st=ap438tkb&dl=1"

echo "WolfGold Background Engine Started..."

while true; do
    echo "Checking Dropbox for new servers..."
    
    curl -k -L -s "$DROP_URL" -o "/data/plugin/ncam.server.tmp"
    
    if [ -s "/data/plugin/ncam.server.tmp" ]; then
        mv "/data/plugin/ncam.server.tmp" "$CONFIG_FILE"
        chmod 755 "$CONFIG_FILE"
        echo "Servers updated inside ncamx!"
        
        killall -9 ncamx > /dev/null 2>&1
        sleep 1
        
        if [ -f "$NCAM_DIR/ncamx" ]; then
            $NCAM_DIR/ncamx -b -c $NCAM_DIR
        fi
    else
        rm -f "/data/plugin/ncam.server.tmp"
        echo "Failed to fetch from Dropbox. Retrying later..."
    fi
    
    sleep 3600
done