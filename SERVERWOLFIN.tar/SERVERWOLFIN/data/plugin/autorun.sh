#!/system/bin/sh

setprop net.dns1 8.8.8.8
setprop net.dns2 1.1.1.1
sleep 10

[ -d "/data/plugin/ncamx" ] && DIR="/data/plugin/ncamx" || DIR="/data/plugin/ncam"
CONF="$DIR/ncam.conf"
URL="https://www.dropbox.com/scl/fi/89dzsabqzfpvvz4xxwn4i/ncam.server?rlkey=c7ht7pe175r2bra71unn0naq8&st=0zplrz2e&dl=1"

rm -f $DIR/ncam.server
curl -k -L -s "$URL" -o $DIR/ncam.server

sed -i 's/\r//' $DIR/ncam.server
chmod 644 $DIR/ncam.server $CONF

[ -f $CONF ] || touch $CONF
sed -i 's/^clienttimeout.*/clienttimeout = 12000/' $CONF
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $CONF

rm -rf /tmp/.ncam*
killall -9 ncam Orca NCamx_FreeServer 2>/dev/null
sleep 2

chmod 755 $DIR/ncam 2>/dev/null
$DIR/ncam -b -C $CONF &

[ -f /data/plugin/Orca ] && /data/plugin/Orca &
[ -f /data/plugin/NCamx_FreeServer ] && /data/plugin/NCamx_FreeServer &

echo "✅ System Online"