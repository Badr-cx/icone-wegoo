/data/fst/run.sh &
