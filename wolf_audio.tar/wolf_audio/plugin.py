# -*- coding: utf-8 -*-
import os, urllib2, json, shutil

SYS_JSON = "/home/gx/local/user_audio.json"
SYS_PICON = "/home/gx/local/picon/"
LOCAL_LOGOS = "/plugin/Wolf/logos/"
M3U_URL = "https://www.dropbox.com/scl/fi/2m2y1a89ecq3x5iszbe1z/AR__BEIN_SPORT_SD-HAMAVM.m3u?rlkey=nkjezbtac1epykpqr4fwz9rmu&st=slx7k58p&dl=1"

def run_sync():
    try:
        response = urllib2.urlopen(M3U_URL)
        lines = response.readlines()
        streams = []
        if not os.path.exists(SYS_PICON): os.makedirs(SYS_PICON)
        for i in range(len(lines)):
            line = lines[i]
            if "#EXTINF" in line:
                name = line.split(",")[-1].strip()
                url = lines[i+1].strip()
                streams.append({"name": name, "url": url, "delay": 0})
                num = "".join(filter(str.isdigit, name))
                local_img = "bein" + num + "sd.png"
                if os.path.exists(LOCAL_LOGOS + local_img):
                    dest = SYS_PICON + name + ".png"
                    shutil.copy(LOCAL_LOGOS + local_img, dest)
                    os.chmod(dest, 0755)
        if not os.path.exists("/home/gx/local/"): os.makedirs("/home/gx/local/")
        with open(SYS_JSON, "w") as f:
            json.dump({"streams": streams}, f)
        os.chmod(SYS_JSON, 0755)
        return True
    except: return False

if __name__ == "__main__":
    run_sync()