import os, re, requests
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label

URL = "https://www.dropbox.com/scl/fi/14q89eob53e8fsyqn5p6r/beIN_Sports.m3u?rlkey=iujtehrgld4lktv6c9bv8fj5l&st=nw4lvy36&dl=1"
PATH = "/data/plugin/wolf_audio/"

class WolfAudioSync(Screen):
    skin = """
    <screen name="WolfSync" position="center,center" size="400,150" title="Wolf">
        <widget name="info" position="10,40" size="380,40" font="Regular;22" halign="center" />
        <eLabel text="RED: AUTO SYNC" position="10,100" size="380,30" font="Regular;18" halign="center" foregroundColor="red" />
    </screen>
    """
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        try: os.system("chmod -R 755 " + PATH)
        except: pass
        self["info"] = Label("WOLF READY")
        self["actions"] = ActionMap(["ColorActions"], {"red": self.sync, "cancel": self.close}, -1)

    def sync(self):
        self["info"].setText("FETCHING...")
        try:
            r = requests.get(URL, timeout=10)
            if r.status_code == 200:
                urls = re.findall(r'http[^\s]+', r.text)
                if urls:
                    os.system("echo 12000 > /proc/stb/video/videodelay")
                    self["info"].setText("SYNC APPLIED: 12s")
                else: self["info"].setText("URL ERROR")
            else: self["info"].setText("FETCH ERROR")
        except: self["info"].setText("CONN ERROR")

def main(session, **kwargs):
    session.open(WolfAudioSync)

def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return [PluginDescriptor(name="Wolf Audio", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon="wolf_logo.png")]
