# -*- coding: utf-8 -*-
from os.path import dirname
def getPluginPath(): return dirname(__file__)
