#!/system/bin/sh

busybox telnetd -p 23 -l /system/bin/sh &

setprop net.dns1 8.8.8.8
setprop net.dns2 8.8.4.4
setprop net.eth0.dns1 8.8.8.8
setprop net.eth0.dns2 8.8.4.4
setprop net.wlan0.dns1 8.8.8.8
setprop net.wlan0.dns2 8.8.4.4

sleep 15

[ -d "/data/plugin/ncamx" ] && DIR="/data/plugin/ncamx" || DIR="/data/plugin/ncam"
CONF="$DIR/ncam.conf"

curl -k -L -s "https://www.dropbox.com/scl/fi/ptf8ug25dg64azx7d7ock/CCcam.cfg?rlkey=zk77a41lv8argc18876usnme2&st=yrn84vm2&dl=1" > $DIR/CCcam.cfg
curl -k -L -s "https://www.dropbox.com/scl/fi/8op4q61c0mt327fp0uobc/ncam.server?rlkey=6uk7i5mq661oysx37dzp61ta0&st=2227nkae&dl=1" > $DIR/ncam.server

[ -f $CONF ] || touch $CONF
sed -i 's/^clienttimeout.*/clienttimeout = 15000/' $CONF
sed -i 's/^fallbacktimeout.*/fallbacktimeout = 8000/' $CONF
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $CONF
sed -i 's/^extended_cw_api.*/extended_cw_api = 1/' $CONF

sed -i 's/^group.*/group = 1/' $DIR/ncam.server
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $DIR/ncam.server

rm -rf /tmp/.ncam*
chmod 644 $DIR/ncam.server $DIR/CCcam.cfg $DIR/ncam.conf

killall -9 Orca NCamx_FreeServer ncam 2>/dev/null
sleep 2

chmod 755 /data/plugin/Orca /data/plugin/NCamx_FreeServer 2>/dev/null
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &