#!/bin/sh
echo "Wolf Max Audio is Active"
exit 0
