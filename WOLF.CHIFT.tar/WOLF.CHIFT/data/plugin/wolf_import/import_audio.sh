#!/bin/sh

TARGET_DIR="/data/tuxbox/config"
TARGET_FILE="$TARGET_DIR/Max-Audio.cfg"
mkdir -p "$TARGET_DIR"

clear
echo "======================================================"
echo "   __      __        _  __   __  __                         "
echo "   \ \    / /       | |/ _| |  \/  |                        "
echo "    \ \  / /__  ___ | | |_  | \  / | __ _ _ __ ___   ___    "
echo "     \ \/ / _ \/ _ \| |  _| | |\/| |/ _\` | '__/ _ \ / __|   "
echo "      \  / (_)  (_) | | |   | |  | | (_| | | | (_) | (__    "
echo "       \/ \___/\___/|_|_|   |_|  |_|\__,_|_|  \___/ \___|   "
echo "======================================================"
echo "          WOLF MAROC - USB AUDIO IMPORTER             "
echo "======================================================"
echo " Scanning USB ports for Audio files...               "
echo "------------------------------------------------------"

# البحث عن ملفات الصوتيات فقط (.cfg أو .m3u) داخل الـ USB
INDEX=1
for usb in /mnt/usb1 /mnt/usb2; do
    if [ -d "$usb" ]; then
        for f in "$usb"/*Max-Audio*.cfg "$usb"/*audio*.cfg "$usb"/*.m3u "$usb"/*.cfg; do
            if [ -f "$f" ]; then
                # استثناء ملفات ncam باش نركزو غير على الصوتيات
                if echo "$f" | grep -q "ncam"; then
                    continue
                fi
                
                eval "FILE_$INDEX=\"$f\""
                echo " [$INDEX] -> \$(basename "$f") (منفذ \$(basename "$usb"))"
                INDEX=\$((INDEX + 1))
            fi
        done
    fi
done

# إذا لم يجد أي ملف
if [ \$INDEX -eq 1 ]; then
    echo "❌ No Audio config files found on USB!"
    echo " Please put your Max-Audio.cfg or .m3u files in USB root."
    echo "======================================================"
    sleep 4
    exit 0
fi

echo " [0] -> Exit Menu"
echo "------------------------------------------------------"
echo -n "Select the audio file to import [0-\$((INDEX - 1))]: "

# قراءة الاختيار من الريموت
read choice

if [ "\$choice" -eq 0 ] 2>/dev/null; then
    echo "Exiting..."
    exit 0
fi

# تنفيذ عملية النسخ والتثبيت ف السيستم
if [ "\$choice" -lt \$INDEX ] 2>/dev/null && [ "\$choice" -gt 0 ] 2>/dev/null; then
    eval "SELECTED_FILE=\$FILE_\$choice"
    
    echo "Importing: \$(basename "\$SELECTED_FILE")..."
    
    cp "\$SELECTED_FILE" "\$TARGET_FILE"
    chmod 644 "\$TARGET_FILE"
    
    echo "------------------------------------------------------"
    echo "✅ Success! Audio tracks updated on Wolf-System."
    echo "------------------------------------------------------"
else
    echo "❌ Invalid choice!"
fi

sleep 3
exit 0
