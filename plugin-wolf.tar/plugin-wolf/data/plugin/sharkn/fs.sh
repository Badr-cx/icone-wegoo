#!/system/bin/sh

# Paths for SharkN (Icone Wegoo)
OUT1="/mnt/plugin/sharkn/ncam.server"
OUT2="/data/plugin/sharkn/ncam.server"

# Clean
rm -f $OUT1 $OUT2 server.txt conv.tmp

# URLs
harr[0]="https://gist.githubusercontent.com/Badr-cx/eb1232c638a8adf7382067a131970de8/raw/gistfile1.txt"
harr[1]="https://cccam-premium.pro/free-cccam/"
harr[2]="https://cccamia.com/cccamfree1/get.php"
harr[3]="http://free.cccambird.com/freecccam.php"

for url in ${harr[@]}; do
    curl -L -k -s --connect-timeout 3 -o server.txt "$url"
    grep -i "C: " server.txt | sed 's/\r//' >> conv.tmp
done

while read LINE; do
    S=$(echo $LINE | awk '{print $2}')
    P=$(echo $LINE | awk '{print $3}')
    U=$(echo $LINE | awk '{print $4}')
    W=$(echo $LINE | awk '{print $5}')

    if [ ! -z "$S" ]; then
        for OUT in $OUT1 $OUT2; do
            [ ! -d "$(dirname $OUT)" ] && mkdir -p "$(dirname $OUT)"
            echo "[reader]" >> $OUT
            echo "label = SharkN_$S" >> $OUT
            echo "protocol = cccam" >> $OUT
            echo "device = $S,$P" >> $OUT
            echo "user = $U" >> $OUT
            echo "password = $W" >> $OUT
            echo "group = 1" >> $OUT
            echo "cccversion = 2.0.11" >> $OUT
            echo "ccckeepalive = 1" >> $OUT
            echo "disablecrccws = 1" >> $OUT
            echo "audisabled = 1" >> $OUT
            echo "" >> $OUT
        done
    fi
done < conv.tmp

# Permissions & Restart
chmod 755 $OUT1 $OUT2
killall -9 ncam > /dev/null 2>&1
/mnt/plugin/sharkn/ncam -b &
rm -f server.txt conv.tmp