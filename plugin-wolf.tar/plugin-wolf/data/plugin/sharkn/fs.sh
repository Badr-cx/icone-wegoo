#!/system/bin/sh

OUTPUT2="/var/bin/sharkn/ncam.server"
rm $OUTPUT2 > /dev/null 2>&1

harr[0]="https://cccamsiptv.com/cccamfree/get.php"
harr[1]="https://cccamgreat.com/free/get.php"
harr[2]="https://cccamover.com/free/get.php"
harr[3]="http://free.cccambird.com/freecccam.php"
harr[4]="http://cccamstore.tv/free-server.php"
harr[5]="https://thecccam.com/cccam-free.php"
harr[6]="http://powerfullcccam.com/powerfull/get.php"
harr[7]="https://mycccam.shop/free-cccam.php"
harr[8]="http://cccamgood.com/free/get2.php"
harr[9]="https://cccamz.com/FREEN12/new0.php"
harr[10]="http://buyiptvcode.com/free6/get2.php"
harr[11]="https://cccamxfree.com/free/get.php"
harr[13]="http://freeccamserver.com/free/get2.php"
harr[14]="https://s.cccamkey.com/cccam24.php"
harr[15]="http://stealthshare.dynu.net/test.html"
harr[16]="https://raw.githubusercontent.com/popking159/softcam/master/cccamt.txt"

for url in ${harr[@]}; do
    curl -L -k -s --connect-timeout 3 -o /tmp/s.txt $url
    grep "C:" /tmp/s.txt > /tmp/c.txt
    while read -r F1 S P U W; do
        if [ ! -z "$S" ]; then
            echo -e "[reader]\nlabel=Free_$S\nprotocol=cccam\ndevice=$S,$P\nuser=$U\npassword=$W\ngroup=1\nccckeepalive=1\ndisablecrccws=1\n" >> $OUTPUT2
        fi
    done < /tmp/c.txt
done

G_RAW="https://raw.githubusercontent.com/Badr-cx/icone-wegoo/refs/heads/main/VERIFIED_CANNON.cfg"
curl -s -L -k $G_RAW -o /tmp/gh.txt
while read -r line; do
    if [[ $line == C:* ]]; then
        S=$(echo $line | awk '{print $2}')
        P=$(echo $line | awk '{print $3}')
        U=$(echo $line | awk '{print $4}')
        W=$(echo $line | awk '{print $5}')
        if [ ! -z "$S" ]; then
            echo -e "[reader]\nlabel=Verified_$S\nprotocol=cccam\ndevice=$S,$P\nuser=$U\npassword=$W\ngroup=1\nccckeepalive=1\ndisablecrccws=1\n" >> $OUTPUT2
        fi
    fi
done < /tmp/gh.txt

rm /tmp/gh.txt /tmp/s.txt /tmp/c.txt > /dev/null 2>&1