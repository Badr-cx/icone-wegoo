#!/system/bin/sh

# Paths for SharkX
OUTPUT1="/mnt/plugin/sharkx/ncam.server"
OUTPUT2="/data/plugin/sharkx/ncam.server"

# Clean
rm -f $OUTPUT1 $OUTPUT2 server.txt conv.tmp

# URLs
harr[0]="https://gist.githubusercontent.com/Badr-cx/eb1232c638a8adf7382067a131970de8/raw/gistfile1.txt"
harr[1]="https://cccam-premium.pro/free-cccam/"
harr[2]="https://cccamia.com/cccamfree1/get.php"
harr[3]="http://free.cccambird.com/freecccam.php"

for url in ${harr[@]}; do
    curl -L -k -s --connect-timeout 3 -o server.txt "$url"
    grep -i "C: " server.txt | sed 's/\r//' > conv.tmp
    
    while read LINE; do
        SERVER=$(echo $LINE | awk '{print $2}')
        PORT=$(echo $LINE | awk '{print $3}')
        USER=$(echo $LINE | awk '{print $4}')
        PASS=$(echo $LINE | awk '{print $5}')

        if [ ! -z "$SERVER" ]; then
            for OUT in $OUTPUT1 $OUTPUT2; do
                [ ! -d "$(dirname $OUT)" ] && mkdir -p "$(dirname $OUT)"
                echo "[reader]" >> $OUT
                echo "label = SharkX_$SERVER" >> $OUT
                echo "protocol = cccam" >> $OUT
                echo "device = $SERVER,$PORT" >> $OUT
                echo "user = $USER" >> $OUT
                echo "password = $PASS" >> $OUT
                echo "group = 1" >> $OUT
                echo "cccversion = 2.0.11" >> $OUT
                echo "disablecrccws = 1" >> $OUT
                echo "ccckeepalive = 1" >> $OUT
                echo "inactivitytimeout = 30" >> $OUT
                echo "" >> $OUT
            done
        fi
    done < conv.tmp
done

chmod 755 $OUTPUT1 $OUTPUT2 > /dev/null 2>&1
rm -f server.txt conv.tmp