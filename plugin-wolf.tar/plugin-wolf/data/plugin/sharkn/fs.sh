#!/system/bin/sh

OUTPUT2="/var/bin/sharkn/ncam.server"
rm $OUTPUT2 > /dev/null 2>&1

harr[0]="https://cccamia.com/cccamfree1/"
harr[1]="https://cccam.net/freecccam"
harr[2]="https://cccam.plus/"

for url in ${harr[@]}; do
    curl -L -k -s --connect-timeout 3 -o /tmp/s.txt $url
    grep "C:" /tmp/s.txt > /tmp/c.txt
    while read -r F1 S P U W; do
        if [ ! -z "$S" ]; then
            echo -e "[reader]\nlabel=Free_$S\nprotocol=cccam\ndevice=$S,$P\nuser=$U\npassword=$W\ngroup=1\nccckeepalive=1\ndisablecrccws=1\n" >> $OUTPUT2
        fi
    done < /tmp/c.txt
done

G_RAW="https://raw.githubusercontent.com/Badr-cx/icone-wegoo/refs/heads/main/VERIFIED_CANNON.cfg"
curl -s -L -k $G_RAW -o /tmp/gh.txt
while read -r line; do
    if [[ $line == C:* ]]; then
        S=$(echo $line | awk '{print $2}')
        P=$(echo $line | awk '{print $3}')
        U=$(echo $line | awk '{print $4}')
        W=$(echo $line | awk '{print $5}')
        if [ ! -z "$S" ]; then
            echo -e "[reader]\nlabel=Verified_$S\nprotocol=cccam\ndevice=$S,$P\nuser=$U\npassword=$W\ngroup=1\nccckeepalive=1\ndisablecrccws=1\n" >> $OUTPUT2
        fi
    fi
done < /tmp/gh.txt

rm /tmp/gh.txt /tmp/s.txt /tmp/c.txt > /dev/null 2>&1

# ضبط الصلاحيات والملكية لجعل الملف root:root
chmod 755 $OUTPUT2
chown 0:0 $OUTPUT2