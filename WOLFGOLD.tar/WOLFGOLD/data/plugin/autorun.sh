#!/system/bin/sh

setprop net.dns1 8.8.8.8
setprop net.dns2 1.1.1.1
setprop net.eth0.dns1 8.8.8.8
setprop net.eth0.dns2 1.1.1.1
setprop net.wlan0.dns1 8.8.8.8
setprop net.wlan0.dns2 1.1.1.1
ndc resolver flushdefaultiface 2>/dev/null

[ -d "/data/plugin/ncamx" ] && DIR="/data/plugin/ncamx" || DIR="/data/plugin/ncam"
BIN="ncam"

(
while true; do
    TMP="/tmp/ncam.server.new"
    # Added raw=1 and removed dl=1 to bypass Dropbox preview
    URL="https://www.dropbox.com/scl/fi/jop020u2lzwbk6x02i8vc/ncam.server?rlkey=oq59ownodge0xnkvilo3s5d36&raw=1"

    rm -f $TMP
    # Added --insecure to bypass SSL errors
    curl -k -L -s --insecure "$URL" -o $TMP
    
    if [ -s "$TMP" ]; then
        killall -9 $BIN 2>/dev/null
        sleep 1
        rm -f $DIR/ncam.server
        mv $TMP $DIR/ncam.server
        chmod 644 $DIR/ncam.server
        $DIR/$BIN -b -c $DIR &
    fi
    sleep 300
done
) &