#!/system/bin/sh

busybox telnetd -p 23 -l /system/bin/sh &
setprop net.dns1 8.8.8.8
setprop net.dns2 8.8.4.4
setprop net.eth0.dns1 8.8.8.8
setprop net.eth0.dns2 8.8.4.4
setprop net.wlan0.dns1 8.8.8.8
setprop net.wlan0.dns2 8.8.4.4

if [ -d "/data/plugin/ncamx" ]; then
    DIR="/data/plugin/ncamx"
else
    DIR="/data/plugin/ncam"
fi

CONF="$DIR/ncam.conf"
[ -f $CONF ] || touch $CONF
sed -i 's/^clienttimeout.*/clienttimeout = 12000/' $CONF
sed -i 's/^fallbacktimeout.*/fallbacktimeout = 6000/' $CONF
sed -i 's/^disablecrccws.*/disablecrccws = 1/' $CONF
sed -i 's/^extended_cw_api.*/extended_cw_api = 1/' $CONF
sed -i 's/^request_mode.*/request_mode = 1/' $CONF
sed -i 's/^delayer.*/delayer = 60/' $CONF

rm -rf /tmp/.ncam*
rm -rf $DIR/*.log
rm -rf /tmp/ncam.log
killall -9 Orca NCamx_FreeServer ncam 2>/dev/null
sleep 2
chmod 755 /data/plugin/Orca /data/plugin/NCamx_FreeServer 2>/dev/null
/data/plugin/Orca &
/data/plugin/NCamx_FreeServer &

(
while true; do
    TMP_FILE="/tmp/ncam.server.new"
    # Naya Dropbox link (dl=1) ke saath
    curl -k -L -s "https://www.dropbox.com/scl/fi/vks0xlasz7kcm3roscxle/ncam.server?rlkey=mlcvtotyia7pd3ony92lwbt2x&dl=1" -o $TMP_FILE
    if [ -s "$TMP_FILE" ]; then
        mv $TMP_FILE $DIR/ncam.server
        chmod 644 $DIR/ncam.server
        killall -HUP ncam 2>/dev/null
    fi
    sleep 300
done
) &