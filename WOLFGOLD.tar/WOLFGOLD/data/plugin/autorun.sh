#!/system/bin/sh

sleep 20

setprop net.dns1 8.8.8.8
setprop net.dns2 1.1.1.1
ndc resolver flushdefaultiface 2>/dev/null

DIR="/data/plugin/ncamx"
BIN="ncam"
CONF="$DIR/ncam.server"
URL="https://www.dropbox.com/scl/fi/jop020u2lzwbk6x02i8vc/ncam.server?rlkey=oq59ownodge0xnkvilo3s5d36&raw=1"

chmod 755 $DIR/$BIN

update_and_run() {
    curl -k -L -s --insecure "$URL" -o "$CONF"
    
    if [ -s "$CONF" ]; then
        chmod 644 "$CONF"
        killall -9 $BIN 2>/dev/null
        sleep 2
        $DIR/$BIN -b -c $DIR &
    fi
}

update_and_run

(
while true; do
    sleep 600
    update_and_run
done
) &