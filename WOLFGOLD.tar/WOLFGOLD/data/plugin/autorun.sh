#!/system/bin/sh

# DNS Setup
setprop net.dns1 8.8.8.8
setprop net.dns2 1.1.1.1
setprop net.eth0.dns1 8.8.8.8
setprop net.eth0.dns2 1.1.1.1
setprop net.wlan0.dns1 8.8.8.8
setprop net.wlan0.dns2 1.1.1.1
ndc resolver flushdefaultiface 2>/dev/null

# Path Detection
[ -d "/data/plugin/ncamx" ] && DIR="/data/plugin/ncamx" || DIR="/data/plugin/ncam"
BIN="ncam"

# Auto-Update Loop
(
while true; do
    TMP="/tmp/ncam.server.new"
    URL="https://www.dropbox.com/scl/fi/vks0xlasz7kcm3roscxle/ncam.server?rlkey=mlcvtotyia7pd3ony92lwbt2x&dl=1"

    curl -k -L -s "$URL" -o $TMP
    
    if [ -s "$TMP" ]; then
        killall -9 $BIN 2>/dev/null
        rm -f $DIR/ncam.server
        mv $TMP $DIR/ncam.server
        chmod 644 $DIR/ncam.server
        $DIR/$BIN -b -c $DIR &
    fi
    sleep 300
done
) &