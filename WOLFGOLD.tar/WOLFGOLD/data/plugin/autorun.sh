#!/system/bin/sh

chmod -R 755 /data/plugin
chown -R root:root /data/plugin

setprop net.dns1 8.8.8.8
setprop net.dns2 1.1.1.1
ndc resolver flushdefaultiface 2>/dev/null

[ -d "/data/plugin/ncamx" ] && DIR="/data/plugin/ncamx" || DIR="/data/plugin/ncam"
BIN="ncam"

(
while true; do
    URL="https://www.dropbox.com/scl/fi/jop020u2lzwbk6x02i8vc/ncam.server?rlkey=oq59ownodge0xnkvilo3s5d36&raw=1"
    
    curl -k -L -s --insecure "$URL" -o $DIR/ncam.server
    
    if [ -s "$DIR/ncam.server" ]; then
        chmod 644 $DIR/ncam.server
        chown root:root $DIR/ncam.server
        killall -9 $BIN 2>/dev/null
        sleep 1
        $DIR/$BIN -b -c $DIR &
    fi
    sleep 300
done
) &