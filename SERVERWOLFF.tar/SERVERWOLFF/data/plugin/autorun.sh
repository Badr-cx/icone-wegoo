#!/system/bin/sh

setprop net.dns1 1.1.1.1
setprop net.dns2 8.8.8.8
sleep 5

[ -d "/data/plugin/ncamx" ] && DIR="/data/plugin/ncamx" || DIR="/data/plugin/ncam"
CONF="$DIR/ncam.conf"

URL="https://pastebin.com/raw/xSxA8mZL"

rm -f $DIR/ncam.server
curl -k -L -s "$URL" > $DIR/ncam.server

sed -i 's/\r//' $DIR/ncam.server
chmod 644 $DIR/ncam.server

[ -f $CONF ] || touch $CONF
sed -i 's/^clienttimeout.*/clienttimeout = 8000/' $CONF
sed -i 's/^fallbacktimeout.*/fallbacktimeout = 4000/' $CONF

rm -rf /tmp/.ncam*
echo 3 > /proc/sys/vm/drop_caches

killall -9 ncam Orca NCamx_FreeServer 2>/dev/null
sleep 2

chmod 755 $DIR/ncam 2>/dev/null
$DIR/ncam -b -C $CONF &

[ -f /data/plugin/Orca ] && /data/plugin/Orca &
[ -f /data/plugin/NCamx_FreeServer ] && /data/plugin/NCamx_FreeServer &

echo "✅ System Online"